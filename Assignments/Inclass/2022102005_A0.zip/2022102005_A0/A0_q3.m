A0_q2
fs = 1/sample_rate;
n = length(t);

x1_noisy = x1+0.3*randn(size(t));
x2_noisy = x2+0.25*randn(size(t));
x3_noisy = x3+0.5*randn(size(t));
x4_noisy = x4+0.25*randn(size(t));

x_noisy_avg = (x1_noisy+x2_noisy+x3_noisy+x4_noisy)/4;

figure;

subplot(5,1,1); 
plot(t, x1_noisy); 
grid on;
title('Noisy 2 Hz Wave'); 
ylabel('Amplitude');

subplot(5,1,2); 
plot(t, x2_noisy); 
grid on;
title('Noisy 8 Hz Wave'); 
ylabel('Amplitude');

subplot(5,1,3);
plot(t, x3_noisy);
grid on;
title('Noisy 12 Hz Wave'); 
ylabel('Amplitude');

subplot(5,1,4); 
plot(t, x4_noisy); 
grid on;
title('Noisy 25 Hz Wave'); 
ylabel('Amplitude');

subplot(5,1,5); 
plot(t, x_noisy_avg);
grid on;
title('Mixed Noisy Signal');
xlabel('Time (s)'); 
ylabel('Amplitude');

y = abs(fft(x_noisy_avg))/n;
f = (0:n-1)*fs/n;

figure;
plot(f,y)
title('fourier transform')
xlabel('frequency(hz)')
ylabel('magnitude')
grid on;
xlim([0,50])