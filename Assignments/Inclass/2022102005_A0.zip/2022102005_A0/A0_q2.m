sample_rate = 1/1000;
t = 0:sample_rate:4;

f1 = 2;
f2 = 8;
f3 = 12;
f4 = 25;

A1 = 1;
A2 = 2;
A3 = 2;
A4 = 1;

p1 = 0;
p2 = pi/2;
p3 = pi;
p4 = 2*pi;

x1 = A1*sin(2*pi*f1*t+p1);
x2 = A2*sin(2*pi*f2*t+p2);
x3 = A3*sin(2*pi*f3*t+p3);
x4 = A4*sin(2*pi*f4*t+p4);

xavg = (x1+x2+x3+x4)/4;

figure;
subplot(5,1,1);
plot(t,x1)
xlabel('time')
ylabel('Amplitude')
title('2Hz sine wave')
grid on;

subplot(5,1,2);
plot(t,x2);
grid on;
xlabel('time')
ylabel('Amplitude')
title('8 Hz sine wave')


subplot(5,1,3);
plot(t,x3);
grid on;
xlabel('time')
ylabel('Amplitude')
title('12Hz sine wave')

subplot(5,1,4);
plot(t,x4);
grid on;
xlabel('time')
ylabel('Amplitude')
title('25 Hz sine wave')

subplot(5,1,5);
plot(t,xavg);
grid on;
xlabel('time')
ylabel('amplitude')
title('Mixed wave')

ts = 1/1000;
fs = 1/ts;
n = length(xavg);

y = abs(fft(xavg))/n;
f = (0:n-1)*fs/n;

figure;
plot(f,y)
title('fourier transform')
xlabel('frequency(hz)')
ylabel('magnitude')
grid on;
xlim([0,50])