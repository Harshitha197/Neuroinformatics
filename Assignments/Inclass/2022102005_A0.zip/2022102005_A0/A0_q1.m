data = load('power.mat');
disp(fieldnames(data));
power_data = data.Power;
disp(size(power_data));

success = power_data(1, :);
fail = power_data(2, :);

[h, p, ci, stats] = ttest(success', fail');

fprintf('Paired t-test result:\n');
fprintf('t(%d) = %.4f, p = %.4f\n', stats.df, stats.tstat, p);

